<?php
// a.mu'ien majid 2022
require("koneksi.php");
$k = $con->query("SELECT * FROM data");
$z = $con->query("SELECT * FROM hitung");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="asset/css/bootstrap.css">
    <link rel="shortcut icon" href="asset/dp.png" type="image/x-icon">
    <link rel="stylesheet" href="asset/css/me.css">
    <title>Pengantar Data Mining | Algoritma C4.5</title>
</head>

<body>
    <h1 class="text-center my-4">Pengantar Data Mining | Algoritma C4.5</h1>
    <hr>
    <div class="container mt-5">
        <?php if (isset($_POST['edit'])) {
            $id = $_POST['id'];
            $data = $con->query("SELECT * FROM data WHERE id ='$id'");
            $z = $data->fetch_assoc();
        ?>
            <h1 class="my-3 text-center">Update Data</h1>
            <form action="update.php" method="POST">
                <input type="hidden" name="id" value="<?= $id; ?>">
                <div class="form-group row my-3">
                    <label for="outlook" class="col-sm-1 col-form-label">Outlook</label>
                    <div class="col-sm-2">
                        <select class="form-select" required name="outlook" aria-label="Default select example">
                            <option selected value="<?= $z['outlook']; ?>"><?= $z['outlook']; ?></option>
                            <option value="Sunny">Sunny</option>
                            <option value="Overcast">Overcast</option>
                            <option value="Rain">Rain</option>
                        </select>
                    </div>
                    <label for="temperatur" class="col-sm-1 col-form-label">Temperatur</label>
                    <div class="col-sm-2">
                        <select class="form-select" required name="temperatur" aria-label="Default select example">
                            <option selected value="<?= $z['temperatur']; ?>"><?= $z['temperatur']; ?></option>
                            <option value="Hot">Hot</option>
                            <option value="Cool">Cool</option>
                            <option value="Mild">Mild</option>
                        </select>
                    </div>
                    <label for="humadity" class="col-sm-1 col-form-label">Humadity</label>
                    <div class="col-sm-2">
                        <select class="form-select" required name="humadity" aria-label="Default select example">
                            <option selected value="<?= $z['humadity']; ?>"><?= $z['humadity']; ?></option>
                            <option value="High">High</option>
                            <option value="Normal">Normal</option>
                        </select>
                    </div>
                    <label for="windy" class="col-sm-1 col-form-label">Windy</label>
                    <div class="col-sm-2">
                        <select class="form-select" required name="windy" aria-label="Default select example">
                            <option selected value="<?= $z['windy']; ?>"><?= $z['windy']; ?></option>
                            <option value="Weak">Weak</option>
                            <option value="Strong">Strong</option>
                        </select>
                    </div>
                </div>
                <div class="form-group row my-3">
                    <label for="play" class="col-sm-1 col-form-label">Play</label>
                    <div class="col-sm-2">
                        <select class="form-select" required name="play" aria-label="Default select example">
                            <option selected value="<?= $z['play']; ?>"><?= $z['play']; ?></option>
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                        </select>
                    </div>
                </div>
                <div class="form-group row my-3">
                    <div class="col-sm-10">
                        <button type="submit" class="btn btn-primary">Update Data</button>
                        <a href="<?php __FILE__; ?>" class="btn btn-danger">Kembali</a>
                    </div>
                </div>
            </form>
        <?php
        } elseif (isset($_GET['act']) == 'tambah') {
        ?>
            <h1 class="my-3 text-center">Tambah Data</h1>
            <form method="post">
                <div class="mb-4 row">
                    <label for="jmlh" class="col-sm-2 col-form-label">Jumlah Data :</label>
                    <div class="col-sm-2">
                        <input type="number" class="form-control" required name="jmlh">
                    </div>
                    <button type="submit" name="submit" class="btn col-sm-1 ms-3 btn-danger">Tambah</button>
                </div>
            </form>
            <form action="simpan.php" method="POST">
                <input type="hidden" name="jmlh" value="<?php if (isset($_POST['jmlh'])) {
                                                            echo $_POST['jmlh'];
                                                        } ?>">
                <?php if (isset($_POST['submit'])) {
                    for ($i = 1; $i <= $_POST['jmlh']; $i++) { ?>
                        <div class="form-group row my-3">
                            <label for="outlook" class="col-sm-1 col-form-label">Outlook <?= $i; ?></label>
                            <div class="col-sm-2">
                                <select class="form-select" required name="outlook[]" aria-label="Default select example">
                                    <option selected>Pilih Outlook</option>
                                    <option value="Sunny">Sunny</option>
                                    <option value="Overcast">Overcast</option>
                                    <option value="Rain">Rain</option>
                                </select>
                            </div>
                            <label for="temperatur" class="col-sm-1 col-form-label">Temperatur <?= $i; ?></label>
                            <div class="col-sm-2">
                                <select class="form-select" required name="temperatur[]" aria-label="Default select example">
                                    <option selected>Pilih Temperatur</option>
                                    <option value="Hot">Hot</option>
                                    <option value="Cool">Cool</option>
                                    <option value="Mild">Mild</option>
                                </select>
                            </div>
                            <label for="humadity" class="col-sm-1 col-form-label">Humadity <?= $i; ?></label>
                            <div class="col-sm-2">
                                <select class="form-select" required name="humadity[]" aria-label="Default select example">
                                    <option selected>Pilih Humadity</option>
                                    <option value="High">High</option>
                                    <option value="Normal">Normal</option>
                                </select>
                            </div>
                            <label for="windy" class="col-sm-1 col-form-label">Windy <?= $i; ?></label>
                            <div class="col-sm-2">
                                <select class="form-select" required name="windy[]" aria-label="Default select example">
                                    <option selected>Pilih Windy</option>
                                    <option value="Weak">Weak</option>
                                    <option value="Strong">Strong</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row my-3">
                            <label for="play" class="col-sm-1 col-form-label">Play <?= $i; ?></label>
                            <div class="col-sm-2">
                                <select class="form-select" required name="play[]" aria-label="Default select example">
                                    <option selected>Pilih Play</option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                            </div>
                        </div>
                    <?php } ?>
                    <div class="form-group row my-3">
                        <div class="col-sm-10">
                            <button type="submit" name="simpan" class="btn btn-primary">Tambah Data Data</button>
                        </div>
                    </div>
                <?php
                } ?>
            </form>
        <?php
        } ?>
        <?php if (!isset($_POST['edit'])) {
        ?>
            <?php if (!isset($_GET['act']) == 'tambah') {
                if (!empty($k->fetch_assoc())) {
                    echo '';
            ?>
                <?php  } else {
                ?>
                    <a href="?act=tambah" class="btn btn-primary mb-2">Tambah Data</a>
                <?php
                }
                ?>
            <?php } ?>
        <?php } ?>
        <?php if (!isset($_POST['edit']) && ($k->num_rows != 0)) {
        ?>
            <?php if ($k->num_rows != 0) {
            ?>
                <?php if ($z->num_rows == 0) {  ?>
                    <a href="hapussemua.php" class="btn btn-danger mb-2">Hapus Semua Data</a>
                <?php  } ?>
                <table class="table table-hover table-striped">
                    <thead class="table-danger">
                        <tr class="text-center">
                            <th scope="col">No</th>
                            <th scope="col">Outlook</th>
                            <th scope="col">Temperature</th>
                            <th scope="col">Humadity</th>
                            <th scope="col">Windy</th>
                            <th scope="col">Play</th>
                            <?php if (empty($z->num_rows)) {
                                echo "<th scope='col'>Aksi</th>";
                            } ?>
                        </tr>
                    </thead>
                    <tbody class="table-sm">
                    <?php   } ?>
                    <?php $i = 1;
                    foreach ($k as $key) {
                    ?>
                        <tr class="text-center">
                            <td><?= $i++; ?></td>
                            <td><?= $key['outlook']; ?></td>
                            <td><?= $key['temperatur']; ?></td>
                            <td><?= $key['humadity']; ?></td>
                            <td><?= $key['windy']; ?></td>
                            <td><?= $key['play']; ?></td>
                            <?php if (empty($z->num_rows)) {
                            ?>
                                <td>
                                    <form method="post">
                                        <input type="hidden" name="id" value="<?= $key['id']; ?>">
                                        <a href="hapus.php?id=<?= $key['id']; ?>" class="btn btn-sm btn-danger">Hapus</a>
                                        <button type="submit" class="btn btn-sm btn-secondary" name="edit">Edit</button>
                                    </form>
                                </td> <?php
                                    } ?>
                        </tr>
                    <?php
                    } ?>
                    </tbody>
                </table>
                <?php if (!$k->num_rows == 0) {
                ?>
                    <form action="hitung.php" method="post">
                        <button type="submit" <?php if (!empty($z->num_rows)) {
                                                    echo "disabled";
                                                } ?> class="btn btn-primary">Hitung</button>
                        <a href="resethitung.php" class="btn btn-warning">Reset</a>
                    </form>
                <?php  } ?>
            <?php } ?>

            <?php if (!empty($z->num_rows) != 0) {
            ?>
                <table class="table  mt-4 table-hover table-striped">
                    <thead class="table-success">
                        <tr class="text-center">
                            <th scope="col">No</th>
                            <th scope="col">Atribut</th>
                            <th scope="col">Nilai</th>
                            <th scope="col">Jumlah Kasus</th>
                            <th scope="col">Yes</th>
                            <th scope="col">No</th>
                            <th scope="col">Entropy</th>
                            <th scope="col">Gain</th>
                        </tr>
                    </thead>
                    <tbody class="table-sm">
                        <?php $i = 1;
                        foreach ($z as $key) {
                        ?>
                            <tr class="text-center <?php if ($key['atribut']) {
                                                        echo 'bg-warning';
                                                    }; ?>">
                                <td><?= $i++; ?></td>
                                <td><?= $key['atribut']; ?></td>
                                <td><?= $key['nilai']; ?></td>
                                <td><?= $key['jumlah_kasus']; ?></td>
                                <td><?= $key['yes']; ?></td>
                                <td><?= $key['no']; ?></td>
                                <td><?php if ($key['entropy'] == 'NAN') {
                                        echo 0;
                                    } else {
                                        echo $key['entropy'];
                                    } ?></td>
                                <td><?= $key['gain']; ?></td>
                            </tr>
                        <?php
                        } ?>
                    </tbody>
                <?php
            }
                ?>
                <?php if (((empty($z->num_rows)) || (!empty($z->num_rows)))) {
                ?>
                    <hr class="bg-danger">
                    <marquee behavior="alternate" direction="right" class="fw-bold mt-2 fa-2x text-danger">Bismillah Tawakkaltu 'Alallah!🤲</marquee>
                    <hr class="bg-danger">
                    <h5 class="text-center fw-bold my-4">&copy; Copyright a.mu'ien majid 2022</h5>
                    <?php if (!empty($z->num_rows)) {
                    ?>
                        <h1 class="text-center">Hasil Perhitungan</h1>
                        <h2 class="mt-2 text-danger text-center">Nilai Max Gain Adalah : <?php foreach ($z as $key) {
                                                                                                $gain[] = $key['gain'];
                                                                                            }
                                                                                            echo max($gain);
                                                                                            $a = max($gain);
                                                                                            $find = $con->query("SELECT * FROM hitung WHERE hitung.gain LIKE '%$a%'");
                                                                                            $d = $find->fetch_assoc();
                                                                                            ?> Dengan Atribut <?= $d['atribut']; ?></h2>
                    <?php
                    } ?>
                <?php } ?>
    </div>


    <script src="asset/js/bootstrap.js"></script>

</body>

</html>