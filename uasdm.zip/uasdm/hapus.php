<?php
// a.mu'ien majid 2022
require 'koneksi.php';
$id = $_GET['id'];
$del = $con->query("DELETE FROM data WHERE id = $id");
if ($del) {
    echo "<script>
        alert('Delete Berhasil');
        document.location.href='index.php';
    </script>";
} else {
    echo "<script>
        alert('delete Gagal');
        document.location.href='index.php';
    </script>";
}
