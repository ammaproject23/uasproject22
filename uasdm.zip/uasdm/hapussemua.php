<?php
// a.mu'ien majid 2022
require 'koneksi.php';

$data = $con->query("SELECT * FROM data ORDER BY id DESC");
$id = $data->fetch_assoc();
for ($i = 0; $i <= $id['id']; $i++) {
    $con->query("DELETE FROM data WHERE id = $i");
}
echo "<script>
        alert('Berhasil Menghapus Semua Data');
        document.location.href='index.php';
    </script>";
