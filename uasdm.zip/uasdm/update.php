<?php
// a.mu'ien majid 2022
require 'koneksi.php';
$id = $_POST['id'];
$outlook = $_POST['outlook'];
$temperatur = $_POST['temperatur'];
$humadity = $_POST['humadity'];
$windy = $_POST['windy'];
$play = $_POST['play'];
$update = $con->query("UPDATE data SET outlook = '$outlook',
                                        temperatur = '$temperatur',
                                        humadity = '$humadity',
                                        windy = '$windy',
                                        play = '$play'
                                        WHERE id = $id");
if ($update) {
    echo "<script>
        alert('Update Berhasil');
        document.location.href='index.php';
    </script>";
} else {
    echo "<script>
        alert('Update Gagal');
        document.location.href='index.php';
    </script>";
}
