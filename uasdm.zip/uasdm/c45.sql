-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 19, 2022 at 08:50 AM
-- Server version: 10.5.16-MariaDB
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `UAS`
--

-- --------------------------------------------------------

--
-- Table structure for table `data`
--

CREATE TABLE `data` (
  `id` int(11) NOT NULL,
  `outlook` varchar(50) NOT NULL,
  `temperatur` varchar(50) NOT NULL,
  `humadity` varchar(50) NOT NULL,
  `windy` varchar(50) NOT NULL,
  `play` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `data`
--

INSERT INTO `data` (`id`, `outlook`, `temperatur`, `humadity`, `windy`, `play`) VALUES
(27, 'Sunny', 'Hot', 'High', 'Weak', 'No'),
(28, 'Sunny', 'Hot', 'High', 'Strong', 'No'),
(29, 'Overcast', 'Hot', 'High', 'Weak', 'Yes'),
(30, 'Rain', 'Mild', 'High', 'Weak', 'Yes'),
(31, 'Rain', 'Cool', 'Normal', 'Weak', 'Yes'),
(32, 'Rain', 'Cool', 'Normal', 'Strong', 'No'),
(33, 'Overcast', 'Cool', 'Normal', 'Strong', 'Yes'),
(34, 'Sunny', 'Mild', 'High', 'Weak', 'No'),
(35, 'Sunny', 'Cool', 'Normal', 'Weak', 'Yes'),
(36, 'Rain', 'Mild', 'Normal', 'Weak', 'Yes'),
(37, 'Sunny', 'Mild', 'Normal', 'Strong', 'Yes'),
(38, 'Overcast', 'Mild', 'High', 'Strong', 'Yes'),
(39, 'Overcast', 'Hot', 'Normal', 'Weak', 'Yes'),
(40, 'Rain', 'Mild', 'High', 'Strong', 'No');

-- --------------------------------------------------------

--
-- Table structure for table `hitung`
--

CREATE TABLE `hitung` (
  `id` int(11) NOT NULL,
  `atribut` varchar(50) DEFAULT NULL,
  `nilai` varchar(50) DEFAULT NULL,
  `jumlah_kasus` int(50) DEFAULT NULL,
  `yes` int(50) DEFAULT NULL,
  `no` int(50) DEFAULT NULL,
  `entropy` text DEFAULT NULL,
  `gain` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hitung`
--

INSERT INTO `hitung` (`id`, `atribut`, `nilai`, `jumlah_kasus`, `yes`, `no`, `entropy`, `gain`) VALUES
(290, 'Total', NULL, 14, 9, 5, '0.94028595867063', 0),
(291, NULL, 'Sunny', 5, 2, 3, '0.97095059445467', 0),
(292, NULL, 'Overcast', 4, 4, 0, 'NAN', 0),
(293, NULL, 'Rain', 5, 3, 2, '0.97095059445467', 0),
(294, 'Outlook', NULL, 0, 0, 0, '0', 0.24675),
(295, NULL, 'Mild', 6, 4, 2, '0.91829583405449', 0),
(296, NULL, 'Hot', 4, 2, 2, '1', 0),
(297, NULL, 'Cool', 4, 3, 1, '0.81127812445913', 0),
(298, 'Temperatur', NULL, 0, 0, 0, '0', 0.0292226),
(299, NULL, 'High', 7, 3, 4, '0.98522813603425', 0),
(300, NULL, 'Normal', 7, 6, 1, '0.59167277858233', 0),
(301, 'Humadity', NULL, 0, 0, 0, '0', 0.151836),
(302, NULL, 'Weak', 8, 6, 2, '0.81127812445913', 0),
(303, NULL, 'Strong', 6, 3, 3, '1', 0),
(304, 'Windy', NULL, 0, 0, 0, '0', 0.048127);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data`
--
ALTER TABLE `data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hitung`
--
ALTER TABLE `hitung`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data`
--
ALTER TABLE `data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `hitung`
--
ALTER TABLE `hitung`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=305;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
