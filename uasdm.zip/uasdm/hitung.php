<?php
// a.mu'ien majid 2022
require("koneksi.php");
total();
sunny();
overcast();
rain();
outlook();
mild();
hot();
cool();
temperatur();
high();
normal();
humadity();
weak();
strong();
windy();

function total()
{
    global $con;
    $n = $con->query("SELECT * FROM data where play='no'");
    $y = $con->query("SELECT * FROM data where play='yes'");
    $data = $con->query("SELECT * FROM data");
    $total = $data->num_rows;
    $no = $n->num_rows;
    $yes = $y->num_rows;
    $entropy = ((- ($yes / $total)) * log(($yes / $total), 2) + (- ($no / $total)) * log(($no / $total), 2));
    $totalh = $con->query("SELECT * FROM hitung where atribut='total'");
    if ($totalh->num_rows == 0) {
        $con->query("INSERT INTO hitung  VALUES ('','Total','','$total','$yes','$no','$entropy','0')");
    }
}
function sunny()
{
    global $con;
    $sunny = $con->query("SELECT * FROM hitung where nilai='sunny'");
    if ($sunny->num_rows == 0) {
        $y = $con->query("SELECT * FROM data where outlook='sunny' AND play='yes'");
        $n = $con->query("SELECT * FROM data where outlook='sunny' AND play='no'");
        $data = $con->query("SELECT * FROM data where outlook='sunny'");
        $total = $data->num_rows;
        $no = $n->num_rows;
        $yes = $y->num_rows;
        $entropy = ((- ($yes / $total)) * log(($yes / $total), 2) + (- ($no / $total)) * log(($no / $total), 2));
        $con->query("INSERT INTO hitung VALUES ('','','Sunny','$total','$yes','$no','$entropy','0')");
    }
}
function overcast()
{
    global $con;
    $overcast = $con->query("SELECT * FROM hitung where nilai='overcast'");
    if ($overcast->num_rows == 0) {
        $y = $con->query("SELECT * FROM data where outlook='overcast' AND play='yes'");
        $n = $con->query("SELECT * FROM data where outlook='overcast' AND play='no'");
        $data = $con->query("SELECT * FROM data where outlook='overcast'");
        $total = $data->num_rows;
        $no = $n->num_rows;
        $yes = $y->num_rows;
        $entropy = ((- ($yes / $total)) * log(($yes / $total), 2) + (- ($no / $total)) * log(($no / $total), 2));
        if ($entropy == "NAN") {
            $entropy = '';
            return $entropy;
            $con->query("INSERT INTO hitung VALUES ('','','Overcast','$total','$yes','$no','$entropy','0')");
        } else {
            $con->query("INSERT INTO hitung VALUES ('','','Overcast','$total','$yes','$no','$entropy','0')");
        }
    }
}
function rain()
{
    global $con;
    $rain = $con->query("SELECT * FROM hitung where nilai='rain'");
    if ($rain->num_rows == 0) {
        $y = $con->query("SELECT * FROM data where outlook='rain' AND play='yes'");
        $n = $con->query("SELECT * FROM data where outlook='rain' AND play='no'");
        $data = $con->query("SELECT * FROM data where outlook='rain'");
        $total = $data->num_rows;
        $no = $n->num_rows;
        $yes = $y->num_rows;
        $entropy = ((- ($yes / $total)) * log(($yes / $total), 2) + (- ($no / $total)) * log(($no / $total), 2));
        if ($entropy == 'NAN') {
            $entropy = 0;
        }
        $con->query("INSERT INTO hitung VALUES ('','','Rain','$total','$yes','$no','$entropy','0')");
    }
}
function outlook()
{
    global $con;
    $rain = $con->query("SELECT * FROM hitung where nilai='rain'");
    $rain_z = $rain->fetch_assoc();
    $overcast = $con->query("SELECT * FROM hitung where nilai='overcast'");
    $overcast_z = $overcast->fetch_assoc();
    $sunny = $con->query("SELECT * FROM hitung where nilai='sunny'");
    $sunny_z = $sunny->fetch_assoc();
    $totalh = $con->query("SELECT * FROM hitung where atribut='total'");
    $total = $totalh->fetch_array();
    $entropy_total = $total['entropy'];
    $jumlah_total = $total['jumlah_kasus'];
    $jumlah_rain = $rain_z['jumlah_kasus'];
    $entropy_rain = $rain_z['entropy'];
    $jumlah_overcast = $overcast_z['jumlah_kasus'];
    $entropy_overcast = $overcast_z['entropy'];
    $jumlah_sunny = $sunny_z['jumlah_kasus'];
    $entropy_sunny = $sunny_z['entropy'];
    if ($entropy_overcast == 'NAN') {
        $entropy_overcast = 0;
    } elseif ($entropy_rain == 'NAN') {
        $entropy_rain = 0;
    } elseif ($entropy_sunny == 'NAN') {
        $entropy_sunny = 0;
    } elseif ($entropy_total == 'NAN') {
        $entropy_total = 0;
    }
    $outlook_gain = $entropy_total - ((($jumlah_rain / $jumlah_total) * $entropy_rain) + (($jumlah_overcast / $jumlah_total) * $entropy_overcast) + (($jumlah_sunny / $jumlah_total) * $entropy_sunny));
    $outlook = $con->query("SELECT * FROM hitung where atribut='outlook'");
    if ($outlook->num_rows == 0) {
        $con->query("INSERT INTO hitung VALUES ('','Outlook','','0','0','0','0','$outlook_gain')");
    }
}
function hot()
{
    global $con;
    $hot = $con->query("SELECT * FROM hitung where nilai='hot'");
    if ($hot->num_rows == 0) {
        $y = $con->query("SELECT * FROM data where temperatur='hot' AND play='yes'");
        $n = $con->query("SELECT * FROM data where temperatur='hot' AND play='no'");
        $data = $con->query("SELECT * FROM data where temperatur='hot'");
        $total = $data->num_rows;
        $no = $n->num_rows;
        $yes = $y->num_rows;
        $entropy = ((- ($yes / $total)) * log(($yes / $total), 2) + (- ($no / $total)) * log(($no / $total), 2));
        if ($entropy == 'NAN') {
            $entropy = 0;
        }
        $con->query("INSERT INTO hitung VALUES ('','','Hot','$total','$yes','$no','$entropy','0')");
    }
}
function mild()
{
    global $con;
    $mild = $con->query("SELECT * FROM hitung where nilai='mild'");
    $jm_mild = $mild->fetch_assoc();
    if ($mild->num_rows == 0) {
        $y = $con->query("SELECT * FROM data where temperatur='mild' AND play='yes'");
        $n = $con->query("SELECT * FROM data where temperatur='mild' AND play='no'");
        $data = $con->query("SELECT * FROM data where temperatur='mild'");
        $total = $data->num_rows;
        $no = $n->num_rows;
        $yes = $y->num_rows;
        $entropy = ((- ($yes / $total)) * log(($yes / $total), 2) + (- ($no / $total)) * log(($no / $total), 2));
        if ($entropy == 'NAN') {
            $entropy = 0;
        }
        $con->query("INSERT INTO hitung VALUES ('','','Mild','$total','$yes','$no','$entropy','0')");
    }
}
function cool()
{
    global $con;
    $cool = $con->query("SELECT * FROM hitung where nilai='cool'");
    if ($cool->num_rows == 0) {
        $y = $con->query("SELECT * FROM data where temperatur='cool' AND play='yes'");
        $n = $con->query("SELECT * FROM data where temperatur='cool' AND play='no'");
        $data = $con->query("SELECT * FROM data where temperatur='cool'");
        $total = $data->num_rows;
        $no = $n->num_rows;
        $yes = $y->num_rows;
        $entropy = ((- ($yes / $total)) * log(($yes / $total), 2) + (- ($no / $total)) * log(($no / $total), 2));
        if ($entropy == 'NAN') {
            $entropy = 0;
        }
        $con->query("INSERT INTO hitung VALUES ('','','Cool','$total','$yes','$no','$entropy','0')");
    }
}
function temperatur()
{
    global $con;
    $hot = $con->query("SELECT * FROM hitung where nilai='hot'");
    $hot_z = $hot->fetch_assoc();
    $mild = $con->query("SELECT * FROM hitung where nilai='mild'");
    $mild_z = $mild->fetch_assoc();
    $cool = $con->query("SELECT * FROM hitung where nilai='cool'");
    $cool_z = $cool->fetch_assoc();
    $totalz = $con->query("SELECT * FROM hitung where atribut='total'");
    $total = $totalz->fetch_array();
    $entropy_total = $total['entropy'];
    $jumlah_cool = $cool_z['jumlah_kasus'];
    $jumlah_total = $total['jumlah_kasus'];
    $entropy_cool = $cool_z['entropy'];
    $jumlah_mild = $mild_z['jumlah_kasus'];
    $entropy_mild = $mild_z['entropy'];
    $jumlah_hot = $hot_z['jumlah_kasus'];
    $entropy_hot = $hot_z['entropy'];
    if ($entropy_total == 'NAN') {
        $entropy_total = 0;
    }
    if ($entropy_cool == 'NAN') {
        $entropy_cool = 0;
    }
    if ($entropy_mild == 'NAN') {
        $entropy_mild = 0;
    }
    if ($entropy_hot == 'NAN') {
        $entropy_hot = 0;
    }
    $temperatur_gain = $entropy_total - ((($jumlah_cool / $jumlah_total) * $entropy_cool) + (($jumlah_mild / $jumlah_total) * $entropy_mild) + (($jumlah_hot / $jumlah_total) * $entropy_hot));
    $outlook = $con->query("SELECT * FROM hitung where atribut='temperatur'");
    if ($outlook->num_rows == 0) {
        $con->query("INSERT INTO hitung VALUES ('','Temperatur','','0','0','0','0','$temperatur_gain')");
    }
}
function high()
{
    global $con;
    $high = $con->query("SELECT * FROM hitung where nilai='high'");
    if ($high->num_rows == 0) {
        $y = $con->query("SELECT * FROM data where humadity='high' AND play='yes'");
        $n = $con->query("SELECT * FROM data where humadity='high' AND play='no'");
        $data = $con->query("SELECT * FROM data where humadity='high'");
        $total = $data->num_rows;
        $no = $n->num_rows;
        $yes = $y->num_rows;
        $entropy = ((- ($yes / $total)) * log(($yes / $total), 2) + (- ($no / $total)) * log(($no / $total), 2));
        if ($entropy == 'NAN') {
            $entropy = 0;
        }
        $con->query("INSERT INTO hitung VALUES ('','','High','$total','$yes','$no','$entropy','0')");
    }
}
function normal()
{
    global $con;
    $normal = $con->query("SELECT * FROM hitung where nilai='normal'");
    if ($normal->num_rows == 0) {
        $y = $con->query("SELECT * FROM data where humadity='normal' AND play='yes'");
        $n = $con->query("SELECT * FROM data where humadity='normal' AND play='no'");
        $data = $con->query("SELECT * FROM data where humadity='normal'");
        $total = $data->num_rows;
        $no = $n->num_rows;
        $yes = $y->num_rows;
        $entropy = ((- ($yes / $total)) * log(($yes / $total), 2) + (- ($no / $total)) * log(($no / $total), 2));
        if ($entropy == 'NAN') {
            $entropy = 0;
        }
        $con->query("INSERT INTO hitung VALUES ('','','Normal','$total','$yes','$no','$entropy','0')");
    }
}
function humadity()
{
    global $con;
    $high = $con->query("SELECT * FROM hitung where nilai='high'");
    $high_z = $high->fetch_assoc();
    $normal = $con->query("SELECT * FROM hitung where nilai='normal'");
    $normal_z = $normal->fetch_assoc();
    $totalh = $con->query("SELECT * FROM hitung where atribut='total'");
    $total = $totalh->fetch_array();
    $entropy_total = $total['entropy'];
    $jumlah_total = $total['jumlah_kasus'];
    $jumlah_normal = $normal_z['jumlah_kasus'];
    $entropy_normal = $normal_z['entropy'];
    $jumlah_high = $high_z['jumlah_kasus'];
    $entropy_high = $high_z['entropy'];
    if ($entropy_total == 'NAN') {
        $entropy_total = 0;
    }
    if ($entropy_normal == 'NAN') {
        $entropy_normal = 0;
    }
    if ($entropy_high == 'NAN') {
        $entropy_high = 0;
    }
    $humadity_gain = $entropy_total - (((0 / $jumlah_total) * 0) + (($jumlah_normal / $jumlah_total) * $entropy_normal) + (($jumlah_high / $jumlah_total) * $entropy_high));
    $outlook = $con->query("SELECT * FROM hitung where atribut='humadity'");
    if ($outlook->num_rows == 0) {
        $con->query("INSERT INTO hitung VALUES ('','Humadity','','0','0','0','0','$humadity_gain')");
    }
}
function weak()
{
    global $con;
    $weak = $con->query("SELECT * FROM hitung where nilai='weak'");
    if ($weak->num_rows == 0) {
        $y = $con->query("SELECT * FROM data where windy='weak' AND play='yes'");
        $n = $con->query("SELECT * FROM data where windy='weak' AND play='no'");
        $data = $con->query("SELECT * FROM data where windy='weak'");
        $total = $data->num_rows;
        $no = $n->num_rows;
        $yes = $y->num_rows;
        $entropy = ((- ($yes / $total)) * log(($yes / $total), 2) + (- ($no / $total)) * log(($no / $total), 2));
        if ($entropy == 'NAN') {
            $entropy = 0;
        }
        $con->query("INSERT INTO hitung VALUES ('','','Weak','$total','$yes','$no','$entropy','0')");
    }
}
function strong()
{
    global $con;
    $strong = $con->query("SELECT * FROM hitung where nilai='strong'");
    if ($strong->num_rows == 0) {
        $y = $con->query("SELECT * FROM data where windy='strong' AND play='yes'");
        $n = $con->query("SELECT * FROM data where windy='strong' AND play='no'");
        $data = $con->query("SELECT * FROM data where windy='strong'");
        $total = $data->num_rows;
        $no = $n->num_rows;
        $yes = $y->num_rows;
        $entropy = ((- ($yes / $total)) * log(($yes / $total), 2) + (- ($no / $total)) * log(($no / $total), 2));
        if ($entropy == 'NAN') {
            $entropy = 0;
        }
        $con->query("INSERT INTO hitung VALUES ('','','Strong','$total','$yes','$no','$entropy','0')");
    }
}
function windy()
{
    global $con;
    $strong = $con->query("SELECT * FROM hitung where nilai='strong'");
    $strong_z = $strong->fetch_assoc();
    $weak = $con->query("SELECT * FROM hitung where nilai='weak'");
    $weak_z = $weak->fetch_assoc();
    $totalh = $con->query("SELECT * FROM hitung where atribut='total'");
    $total = $totalh->fetch_array();
    $entropy_total = $total['entropy'];
    $jumlah_total = $total['jumlah_kasus'];
    $jumlah_strong = $strong_z['jumlah_kasus'];
    $entropy_strong = $strong_z['entropy'];
    $jumlah_weak = $weak_z['jumlah_kasus'];
    $entropy_weak = $weak_z['entropy'];
    if ($entropy_total == 'NAN') {
        $entropy_total = 0;
    }
    if ($entropy_strong == 'NAN') {
        $entropy_strong = 0;
    }
    if ($entropy_weak == 'NAN') {
        $entropy_weak = 0;
    }
    $windy_gain = $entropy_total - (((0 / $jumlah_total) * 0) + (($jumlah_strong / $jumlah_total) * $entropy_strong) + (($jumlah_weak / $jumlah_total) * $entropy_weak));
    $outlook = $con->query("SELECT * FROM hitung where atribut='windy'");
    if ($outlook->num_rows == 0) {
        $con->query("INSERT INTO hitung VALUES ('','Windy','','0','0','0','0','$windy_gain')");
    }
}

echo "<script>
        alert('Menghitung Berhasil 😋');
        document.location.href='index.php';
    </script>";
