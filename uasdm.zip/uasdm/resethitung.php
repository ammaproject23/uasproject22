<?php
// a.mu'ien majid 2022
require 'koneksi.php';

$data = $con->query("SELECT * FROM hitung ORDER BY id DESC");
$del = $data->fetch_array();
if (!$del) {
    echo "<script>
        alert('Data Sudah Kosong 😑');
        document.location.href='index.php';
    </script>";
}
for ($i = 0; $i <= $del['id']; $i++) {
    $con->query("DELETE FROM hitung WHERE id = $i");
}
echo "<script>
        alert('Reset Berhasil 😋');
        document.location.href='index.php';
    </script>";
