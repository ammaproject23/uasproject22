<?php
// a.mu'ien majid 2022
require 'koneksi.php';
$xz = 0;
for ($i = 1; $i <= $_POST['jmlh']; $i++) {
    $outlook = $_POST['outlook'];
    $temperatur = $_POST['temperatur'];
    $humadity = $_POST['humadity'];
    $windy = $_POST['windy'];
    $play = $_POST['play'];
    $con->query("INSERT INTO data VALUES ('','$outlook[$xz]','$temperatur[$xz]','$humadity[$xz]','$windy[$xz]','$play[$xz]')");
    $xz++;
}
echo "<script>
        alert('Data Berhasil Disimpan');
        document.location.href='index.php';
    </script>";
